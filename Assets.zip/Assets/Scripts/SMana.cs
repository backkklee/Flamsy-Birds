using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class SMana : MonoBehaviour
{

    public void gotoChoose_character() {
        SceneManager.LoadScene(SceneData.choose_character);
    }

    public void gobacktoHome() {
        SceneManager.LoadScene(SceneData.home);
    }

    public void gotoFlamsy_Bird() {
        GameStatus.Instance.ResetS();
        SceneManager.LoadScene(SceneData.Flamsy_Bird);
    }
}
