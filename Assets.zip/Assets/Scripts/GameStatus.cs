using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class GameStatus : MonoBehaviour
{
    public static GameStatus Instance; 

    public int Score;
    public int HighScore;

    private void Awake()
    {
        Instance = this;
    }

    void Start()
    {   
        Score=PlayerPrefs.GetInt("Score",0);
        HighScore=PlayerPrefs.GetInt("HighScore",0);
        PlayerPrefs.SetInt("Score",Score);
        PlayerPrefs.SetInt("HighScore",HighScore);
    }
    void OnDestroy()
    {
        PlayerPrefs.SetInt("Score",Score);
        PlayerPrefs.SetInt("HighScore",HighScore);
    }

    public void IncreaseScore()
    {
        Score++;
        updateHS();
    }

    public void updateHS()
    {
        if(Score>HighScore){
            HighScore=Score;
        }
    }

    public void ResetS()
    {
        Score=0;
    }
}
