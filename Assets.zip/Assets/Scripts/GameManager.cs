using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour
{
    public static GameManager Instance { get; private set; }

    [SerializeField] private Player player;


    private void Awake()
    {
        if (Instance != null)
        {
            DestroyImmediate(gameObject);
        }
        else
        {
            Instance = this;
            Application.targetFrameRate = 60;
            Pause();
        }
    }

    void Start()
    {
        //GameStatus.Instance.ResetS();
        Time.timeScale = 1f;
        player.enabled = true;
        
        Towers[] towers = FindObjectsOfType<Towers>();

        for (int i = 0; i < towers.Length; i++) {
            Destroy(towers[i].gameObject);
        }
    }

    public void GameOver()
    {
        SceneManager.LoadScene(SceneData.Game_End);
    }

    public void Pause()
    {
        Time.timeScale = 0f;
        player.enabled = false;
    }
}
