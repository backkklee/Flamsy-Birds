using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SceneData : MonoBehaviour
{
    public static int home = 0;
    public static int choose_character = 1;
    public static int Flamsy_Bird = 2;
    public static int Game_End = 3;
}
