using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class HighScore : MonoBehaviour
{
    public void Update()
    {
        GameObject go = GameObject.Find("GameStatus");

        if(go==null)
        {
            this.enabled = false;
            return;
        }

        GameStatus gs= go.GetComponent<GameStatus>();

        GetComponent<Text>().text=gs.HighScore.ToString();
    }
    
}
